/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Naveels PC
 */
public class LoginPageController implements Initializable {

    @FXML
    private ComboBox<String> userTypecomboBox;
    @FXML
    private Button loginButton;
    @FXML
    private Button signupButton;
    @FXML
    private AnchorPane loginPageAnchorPane;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        userTypecomboBox.setItems(FXCollections.observableArrayList("Assistant Superintendent of Police","Inspector","Officer in Charge","Constable","Civilian","Sub Inspector","Surgent"));
        
    }    
    @FXML
    private void signupButtonOnClick(MouseEvent event) throws IOException{
        
        Parent root = FXMLLoader.load(getClass().getResource("SelectUserTypePage.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
    }

    @FXML
    private void loginButtonOnClick(MouseEvent event){
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        try
        {
            f = new File("accounts.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            try{
                Parent root = null;
                while(true)
                {
                    LoginPage obj= (LoginPage)ois.readObject();
                    if(obj.getUsername().equals(username.getText()) && obj.getPassword().equals(password.getText()) && obj.getUserTypecomboBox(userTypecomboBox.getValue()))
                    {
                        Gulshan_Model_Thana.setLogged_in_username(username.getText());
                        Gulshan_Model_Thana.setLogged_in_user_type(userTypecomboBox.getValue());
                        if(obj.getUserTypecomboBox().equals("Assistant Supeintendent of Police"))
                        {
                            root= FXMLLoader.load(getClass().getResource("Assistant Superintendent of Police.fxml"));
                            break;
                        }else if(obj.getUserTypecomboBox().equals("Inspector"))
                        {
                            root= FXMLLoader.load(getClass().getResource("Inspector.fxml"));
                            break;
                        }else if(obj.getUserTypecomboBox().equals("Constable"))
                        {
                            root= FXMLLoader.load(getClass().getResource("Constable.fxml"));
                            break;
                        }else if(obj.getUserTypecomboBox().equals("Citizen"))
                        {
                            root= FXMLLoader.load(getClass().getResource("Citizen.fxml"));
                            break;
                        }
                       
                    }
                }
                Scene new_scene = new Scene(root);    
                Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                window.setScene(new_scene);
                window.show();
            }catch(Exception e)
            {
                //Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }catch(Exception ex)
        {
            Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            try
            {
                if(ois != null) ois.close();
            }catch(IOException ex)
            {
                Logger.getLogger(LoginPageController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }


    
}
