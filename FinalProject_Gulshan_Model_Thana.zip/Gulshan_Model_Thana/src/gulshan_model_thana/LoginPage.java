/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import java.io.Serializable;

/**
 *
 * @author Naveels PC
 */
public class LoginPage implements Serializable {
    private final String username;
    private final String password;
    private final String userTypecomboBox;

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getUserTypecomboBox() {
        return userTypecomboBox;
    }

    public LoginPage(String a, String b, String c) {
        this.username = a;
        this.password = b;
        this.userTypecomboBox = c;
    }

    boolean getUserTypecomboBox(String value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
