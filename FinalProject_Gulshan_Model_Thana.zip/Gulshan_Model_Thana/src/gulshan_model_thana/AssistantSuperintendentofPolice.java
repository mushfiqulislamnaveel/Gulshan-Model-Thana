/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Naveels PC
 */
public class AssistantSuperintendentofPolice extends User implements Serializable{

    public AssistantSuperintendentofPolice(String username, String password) {
        super(username, password);
    }
    public static AssistantSuperintendentofPolice search_and_return_ASP_user_obj_from_file(String username){
        File f=null;
        FileInputStream fis=null;
        ObjectInputStream ois=null;
        //System.out.println("Hello");
        AssistantSuperintendentofPolice obj=null;
        try {
            f = new File("ASP_users.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            try {
                while(true){
                   obj=(AssistantSuperintendentofPolice)ois.readObject();
                   if(obj.getUsername().equals(username)){
                       break;
                   }
                }
            } catch (Exception ex) {
                Logger.getLogger(AssistantSuperintendentofPolice.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
           Logger.getLogger(AssistantSuperintendentofPolice.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                if(ois != null) ois.close();
            } catch (IOException ex) {
                Logger.getLogger(AssistantSuperintendentofPolice.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return obj;
    }  
}
