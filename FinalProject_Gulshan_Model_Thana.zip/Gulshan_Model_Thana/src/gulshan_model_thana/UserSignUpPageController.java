/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Naveels PC
 */
public class UserSignUpPageController implements Initializable {

    @FXML
    private TextField nameField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    @FXML
    private void signUpOnClick(ActionEvent event) throws IOException{
        String user_type = Gulshan_Model_Thana.getCreate_an_account_user_type();
        File f= null;
        FileOutputStream fos=null;
        ObjectOutputStream oos=null;
        if(user_type.equals("Officer in Charge"))
        {
            Inspector obj2 = new Inspector(nameField.getText(),addressField.getText(),username.getText(),password.getText());
            try
            {
                f =new File("OCUser.bin");
                if(f.exists())
                {
                    fos = new FileOutputStream(f, true);
                    oos = new AppendableObjectOutputStream(fos);
                }else
                {
                    fos = new FileOutputStream(f);
                    oos = new ObjectOutputStream(fos);
                }oos.writeObject(obj2);
            }catch(IOException ex)
            {
              Logger.getLogger(UserSignUpPageController.class.getName()).log(Level.SEVERE, null, ex); 
            }finally
            {
                if(oos != null) oos.close();
            }
        }else if(user_type.equals("Constable"))
        {
            Constable obj2 = new Constable(nameField.getText(),addressField.getText(),username.getText(),password.getText());
            try
            {
                f =new File("ConstableUser.bin");
                if(f.exists())
                {
                    fos = new FileOutputStream(f,true);
                    oos = new AppendableObjectOutputStream(fos);
                }else
                {
                    fos = new FileOutputStream(f);
                    oos = new ObjectOutputStream(fos);
                }oos.writeObject(obj2);
            }catch(FileNotFoundException ex)
            {
              Logger.getLogger(UserSignUpPageController.class.getName()).log(Level.SEVERE, null, ex); 
            }finally
            {
                if(oos != null) oos.close();
            }
        }else if(user_type.equals("Citizen"))
        {
            Citizen obj2 = new Citizen(nameField.getText(),addressField.getText(),username.getText(),password.getText());
            try
            {
                f =new File("CitizenUser.bin");
                if(f.exists())
                {
                    fos = new FileOutputStream(f,true);
                    oos = new AppendableObjectOutputStream(fos);
                }else
                {
                    fos = new FileOutputStream(f);
                    oos = new ObjectOutputStream(fos);
                }oos.writeObject(obj2);
            }catch(FileNotFoundException ex)
            {
              Logger.getLogger(UserSignUpPageController.class.getName()).log(Level.SEVERE, null, ex); 
            }finally
            {
                if(oos != null) oos.close();
            }
        }
        Parent root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
    }
}
