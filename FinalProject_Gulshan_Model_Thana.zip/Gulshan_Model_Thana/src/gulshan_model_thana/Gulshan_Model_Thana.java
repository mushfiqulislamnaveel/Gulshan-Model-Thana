/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Naveels PC
 */
public class Gulshan_Model_Thana extends Application {

    private static String logged_in_username;
    private static String logged_in_user_type;
    private static String create_an_account_user_type;

    public static String getCreate_an_account_user_type() {
        return create_an_account_user_type;
    }

    public static void setLogged_in_user_type(String logged_in_user_type) {
        Gulshan_Model_Thana.logged_in_user_type = logged_in_user_type;
    }

    public static String getLogged_in_user_type() {
        return logged_in_user_type;
    }

    public static void setCreate_an_account_user_type(String create_an_account_user_type) {
        Gulshan_Model_Thana.create_an_account_user_type = create_an_account_user_type;
    }
    
    public static String getLogged_in_username() {
        return logged_in_username;
    }

    public static void setLogged_in_username(String logged_in_username) {
        Gulshan_Model_Thana.logged_in_username = logged_in_username;
    }
    /*experiment
    
    
    */
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        // TODO code application logic here
        launch(args);
    }
    
}
