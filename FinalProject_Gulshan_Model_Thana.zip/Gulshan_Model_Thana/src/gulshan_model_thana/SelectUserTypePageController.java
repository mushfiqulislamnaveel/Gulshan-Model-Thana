/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Naveels PC
 */
public class SelectUserTypePageController implements Initializable {

    @FXML
    private ComboBox<String> userTypecomboBox;

    @FXML
    private void userTypeComboBoxUpdated(ActionEvent event) {
        String s = userTypecomboBox.getSelectionModel().getSelectedItem().toString();
        
    }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         userTypecomboBox.setItems(FXCollections.observableArrayList("Assistant Superintendent of Police","Inspector","Officer in Charge","Constable","Civilian","Sub Inspector","Surgent"));
    }    

    @FXML
    private void nextBtnOnClick(MouseEvent event) throws IOException{
        Parent root =null;
        if(userTypecomboBox.getValue().equals("Officer in Charge") || userTypecomboBox.getValue().equals("Assistant Superintendent of Police")){
            root = FXMLLoader.load(getClass().getResource("OCASPSignUpPage.fxml"));
        }
        else{
            root = FXMLLoader.load(getClass().getResource("UserSignUpPage.fxml"));
        }
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
        
        Gulshan_Model_Thana.setCreate_an_account_user_type(userTypecomboBox.getValue());
    }
    
    
}
