/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Naveels PC
 */
public class AssistantSuperintendentOfPoliceController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void viewCaseReportBtnOnClick(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ViewCaseReport.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
    }
 

    @FXML
    private void viewJoiningInformationBtnOnClick(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ViewJoiningInformation.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
    }

    @FXML
    private void checkDutyTImeBtnOnClick(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("CheckDutyTime.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
    }


    @FXML
    private void viewApplyPromotionBtnOnClick(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("ViewApplyPromotion.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();

    }
    
    @FXML
    private void logOutBtnOnClick(ActionEvent event) throws IOException {
        
        Parent root = FXMLLoader.load(getClass().getResource("LoginPage.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();
        
    }
}
