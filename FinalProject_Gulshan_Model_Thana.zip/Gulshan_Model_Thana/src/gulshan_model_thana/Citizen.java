/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gulshan_model_thana;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author turag
 */
public class Citizen implements Initializable {

    Citizen(String text, String text0, String text1, String text2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void applicationofpoliceverificationOnclick(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("applicationforpoliceverification.fxml"));
        Scene new_scene = new Scene(root);    
        Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        window.setScene(new_scene);
        window.show();} 
    

    @FXML
    private void fileagdOnclick(MouseEvent event) {
    }

    @FXML
    private void policenumberOnclick(MouseEvent event) {
    }

    @FXML
    private void reportcyberbullingcaseOnclick(MouseEvent event) {
    }

    @FXML
    private void fileacomplainagainstpoOnclick(MouseEvent event) {
    }
    
}
